package beans;

import java.util.List;

public class Test {
	private int cost;
	private String item;
	private List<String> list;

	public Test(int cost, String item) {
		super();
		this.cost = cost;
		this.item = item;
		System.out.println("public Test(int cost, String item)");
	}

	
	public Test(List<String> list) {
		super();
		this.cost = Integer.parseInt(list.get(0));
		this.item = list.get(1);
		System.out.println("Test(List<String> list)");
	}
	@Override
	public String toString() {
		return "Test [cost=" + cost + ", item=" + item + "]";
	}

}
