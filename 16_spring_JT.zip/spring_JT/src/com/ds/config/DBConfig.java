package com.ds.config;

import java.sql.SQLException;

import javax.annotation.PreDestroy;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class DBConfig {

	@Bean
	public BasicDataSource createCP() {
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("oracle.jdbc.OracleDriver");
		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		bds.setUsername("system");
		bds.setPassword("admin");
		bds.setMaxActive(150);
		bds.setMaxWait(2000);
		return bds;
	}

	@Bean
	public JdbcTemplate createJT() {
		JdbcTemplate jt = new JdbcTemplate();
		jt.setDataSource(createCP());
		return jt;
	}

	@PreDestroy
	public void closeAllResources() {
		BasicDataSource bds = createCP();
		try {
			bds.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
