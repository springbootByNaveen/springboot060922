package com.ds.web;

import java.util.List;
import java.util.Map;

import javax.swing.Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;

import com.ds.repository.Student;
import com.ds.services.StudentService;

@Controller
public class StudentController {
	@Autowired
	StudentService service;

	public void createStudentAPI(int id, String name, String email, String address) throws Exception {
		service.createStudent(id, name, email, address);
	}

	public void updateStudentAPI(int id, String name, String email, String address) throws Exception {
		service.updateStudent(id, name, email, address);
	}

	public void deleteStudentAPI(int id) throws Exception {
		service.delete(id);
	}

	public Map selectStudentAPI(int id) throws Exception {
		return service.selectmap(id);
	}

	public Student selectStudentObjectAPI(int id) throws Exception {
		return service.selectStudent(id);
	}

	public List selectAllAPI() throws Exception {
		return service.selectAllStudent();
	}

}
