package com.ds.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StudentRSBean implements RowMapper<Student> {

	@Override
	public Student mapRow(ResultSet rs, int arg) throws SQLException {
		Student std = new Student();
		std.setId(rs.getInt(1));
		std.setName(rs.getString(2));
		std.setEmail(rs.getString(3));
		std.setAddress(rs.getString(4));

		return std;
	}

}
