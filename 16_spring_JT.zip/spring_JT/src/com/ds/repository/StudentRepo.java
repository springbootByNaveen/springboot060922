package com.ds.repository;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StudentRepo {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public void save(int id, String name, String email, String address) throws Exception {
		Object args[]=new Object[] { id, name, email, address};
		jdbcTemplate.update("insert into STUDENT_TABLE values(?,?,?,?)",args);
	}

	public void update(int id, String name, String email, String address) throws Exception {
		jdbcTemplate.update("update STUDENT_TABLE set name=?,email=?,address=? where id=?", name, email, address, id);
	}

	public void delete(int id) throws Exception {
		jdbcTemplate.update("delete STUDENT_TABLE where id=?", id);
	}

	public Map select(int id) throws Exception {
		Map map = jdbcTemplate.queryForMap("select * from STUDENT_TABLE where id=?", id);
		// map.put("ID",123);map.put("NAME","ABCD"); etc....
		return map;
	}

	public Student selectObject(int id) throws Exception {
		Student student = jdbcTemplate.queryForObject("select * from STUDENT_TABLE where id=?", new Object[] { id },
				new StudentRSBean());
		return student;
	}

	public List selectAll() throws Exception {
		List list = jdbcTemplate.queryForList("select * from STUDENT_TABLE");
		return list;
	}

}
