package com.ds.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.repository.Student;
import com.ds.repository.StudentRepo;

@Service
public class StudentService {
	@Autowired
	StudentRepo repo;
	public void createStudent(int id, String name, String email, String address) throws Exception {
		repo.save(id, name, email, address);
	}

	public void updateStudent(int id, String name, String email, String address) throws Exception {
	
		repo.update(id, name, email, address);
		
	}
	public void delete(int id) throws Exception {
		repo.delete(id);
	}

	public Map selectmap(int id) throws Exception {
		return repo.select(id);
	}

	public Student selectStudent(int id) throws Exception {
		return repo.selectObject(id);
	}

	public List selectAllStudent() throws Exception {
		return repo.selectAll();
	}
}
