package app;

import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ds.repository.Student;
import com.ds.web.StudentController;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/ioc.xml");
		StudentController controller = context.getBean(StudentController.class);
		String[] names = context.getBeanDefinitionNames();
		for (String beanName : names) {
			System.out.println(beanName);
		}
		/*
		 * for (int i = 10000; i < 20000; i++) { int studentId = i + 1; String name =
		 * "testName" + studentId; String email = "testEamil" + studentId; String
		 * address = "testaddress" + studentId;
		 * 
		 * try { controller.createStudentAPI(studentId, name, email, address); } catch
		 * (Exception e) { e.printStackTrace(); }
		 * 
		 * }
		 */

		try {
			Map map = controller.selectStudentAPI(123);
			Set<String> keys = map.keySet();
			for (String key : keys) {
				System.out.println(key + ":" + map.get(key));
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			Student student = controller.selectStudentObjectAPI(123);

			System.out.println(student.getId());
			System.out.println(student.getName());
			System.out.println(student.getEmail());
			System.out.println(student.getAddress());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
/*
		try {
			List students = controller.selectAllAPI();
			for (Object obj : students) {
				Map map = (Map) obj;
				System.out.print(map.get("ID") + ",");
				System.out.print(map.get("NAME") + ",");
				System.out.print(map.get("EMAIL") + ",");
				System.out.print(map.get("ADDRESS") + ",");
				System.out.println("----------------------------------------");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}
	
}
