package beans;

public class CalBusiness {
	
	
	public int add(int a, int b) {
		return a + b;
	}
}
