package beans;

public class CalUI {
	CalBusiness business;

	public void setBusiness(CalBusiness business) {
		this.business = business;
	}

	public void addNumber(int a, int b) {
		System.out.println(business.add(a, b));
	}
}
