package beans;

public class JioSim implements SIM{
	
	@Override
	public void call(String number) {
	System.out.println("dailing number: "+number);		
	}
	
	@Override
	public void connectInternet(String url) {
		System.out.println("connecting to: "+url);	
	}
	
	@Override
	public void messages(String number) {
		System.out.println("sending message to: "+number);		
	}

}
