package beans;

public interface SIM {
	public void call(String number);
	public void connectInternet(String url);
	public void messages(String number);
}
