package beans;

public class Phone {

	SIM sim;

	/*
	 * public void setSim(SIM sim) { this.sim = sim; }
	 */
	
	public Phone(SIM sim) {
		this.sim=sim;
	}
	public void dailNumber(String phoneNumber) {
		sim.call(phoneNumber);
	}

	public void browse(String url) {
		sim.connectInternet(url);
	}

	public void textAMessage(String phoneNumber) {
		sim.messages(phoneNumber);
	}

}
