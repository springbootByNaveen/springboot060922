package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Bus;
import beans.Car;

public class Application {
	public static void main(String[] args) {
		// early
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/ioc.xml");
		System.out.println("----------------------------------------------------------");

		Car c = (Car) context.getBean("c1");
		c.carInfo();
		
		Bus b = (Bus) context.getBean("b");
		b.busInfo();
		
		/*
		 * Car c2 = (Car) context.getBean("c2"); c2.carInfo();
		 */

		

	}
}
