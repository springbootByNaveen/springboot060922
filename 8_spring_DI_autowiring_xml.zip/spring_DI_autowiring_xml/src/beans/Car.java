package beans;

public class Car {
	
	private String carModel;
	Engine engine;
	Tires tires;

	public void setCarModel(String carModel) {
		System.out.println("setCarModel(String carModel)");
		this.carModel = carModel;
	}

	public void setEngine(Engine engine) {
		System.out.println("setEngine(Engine engine)");
		this.engine = engine;
	}

	public void setTires(Tires tires) {
		System.out.println("setTires(Tires tires)");
		this.tires = tires;
	}

	public void carInfo() {
		System.out.println("CC=" + engine.getCc());
		System.out.println("TIRE SIZE=" + tires.getSize());
		System.out.println("carModel=" + carModel);
	}

}
