package beans;

public class Bus {
	private Engine engine;
	private Tires tires;

	public Bus(Engine engine, Tires tires) {
		super();
		System.out.println("Bus(Engine engine, Tires tires)");
		this.engine = engine;
		this.tires = tires;
	}
	
	public void setEngine(Engine engine) {
		System.out.println("setEngine in Bus");
		this.engine = engine;
	}
	public void setTires(Tires tires) {
		System.out.println("setTires in Bus");
		this.tires = tires;
	}
	public void busInfo() {
		System.out.println("BUS CC="+engine.getCc());
		System.out.println("BUS TIRE SIZE="+tires.getSize());
	}

}
