package beans;

public class Engine {
	private String cc;// no autowiring

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getCc() {
		return cc;
	}

}
