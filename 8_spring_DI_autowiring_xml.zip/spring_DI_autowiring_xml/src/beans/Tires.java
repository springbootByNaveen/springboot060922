package beans;

public class Tires {
	private String size;

	public void setSize(String size) {
		this.size = size;
	}

	public String getSize() {
		return size;
	}
}
