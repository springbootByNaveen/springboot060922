package beans;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionBean {
	
	private List<String> alpL;
	private Set<String> alpU;
	private Map<String,String> stateCap;
	
	public void setAlpL(List<String> alpL) {
		System.out.println("setAlpL");
		this.alpL = alpL;
	}
	public void setAlpU(Set<String> alpU) {
		System.out.println("setAlpU");
		this.alpU = alpU;
	}
	public void setStateCap(Map<String, String> stateCap) {
		System.out.println("setStateCap");
		this.stateCap = stateCap;
	}
	@Override
	public String toString() {
		return "CollectionBean [alpL=" + alpL + ", alpU=" + alpU + ", stateCap=" + stateCap + "]";
	}
	
	
	

}
