package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.CollectionBean;

public class Application {
	public static void main(String[] args) {
		// early
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/ioc.xml");
		System.out.println("----------------------------------------------------------");
		CollectionBean cb = context.getBean(CollectionBean.class);
		System.out.println(cb);
	}
}
