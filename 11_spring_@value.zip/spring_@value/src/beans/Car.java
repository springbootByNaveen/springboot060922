package beans;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;

@Controller
public class Car {
	@Autowired
	Engine engine;
	
	@Value("#{new beans.Engine('1000cc',2021,'xyz')}")
	Engine engine1;
	@Value("#{new java.util.ArrayList()}")
	List<String> list;
	
	public Car() {
	System.out.println("Car()");
	}

	public void printInfo() {
		System.out.println(engine.getEngCC());
		System.out.println(engine.getYear());
		System.out.println(engine.getMaker());
		System.out.println(engine1.getEngCC());
		System.out.println(engine1.getYear());
		System.out.println(engine1.getMaker());
		System.out.println(list);
	}
}
