package beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class Engine {
	@Value("${cc}")
	private String engCC;
	@Value("${year}")
	private int year;
	@Value("${maker:maruthi}")
	private String maker;

	public Engine() {
		System.out.println("Engine()");
	}
	
	public Engine(String cc,int year,String maker) {
		this.engCC=cc;
		this.year=year;
		this.maker=maker;
	}
	

	public String getEngCC() {
		return engCC;
	}

	public int getYear() {
		return year;
	}
	public String getMaker() {
		return maker;
	}
}
