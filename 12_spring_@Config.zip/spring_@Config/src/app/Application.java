package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.uti.Eutil;

public class Application {
	public static void main(String[] args) {
		// early
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/ioc.xml");
		System.out.println("----------------------------------------------------------");
		Eutil e = context.getBean(Eutil.class);
		e.createCon();
		e.createCon();
		e.createCon();
		
		/*
		 * DConfig c=context.getBean(DConfig.class); c.createCon(); c.createCon();
		 * c.createCon();
		 */
	}
}
