package com.org.config;

import java.sql.Connection;
import java.sql.DriverManager;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

//@SpringBootApplication
@Configuration
public class DConfig {
	public DConfig() {
		System.out.println("DConfig()");
	}

	@Bean
	public Connection createCon() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			System.out.println(con);
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Bean
	public SessionFactory createSf() {
		try {
			org.hibernate.cfg.Configuration cf = new org.hibernate.cfg.Configuration();
			SessionFactory sf = cf.buildSessionFactory();
			return sf;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Bean
	public RestTemplate createRT() {
		try {
			return new RestTemplate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
