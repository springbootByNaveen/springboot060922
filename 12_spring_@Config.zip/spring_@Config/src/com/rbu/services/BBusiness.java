package com.rbu.services;

import org.springframework.stereotype.Service;

@Service
public class BBusiness {
	public BBusiness() {
		System.out.println("BBusiness");
	}

}
