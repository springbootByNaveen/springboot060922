package com.rbu.dao;

import org.springframework.stereotype.Repository;

@Repository
public class CDao {
	public CDao() {
		System.out.println("CDao()");
	}

}
