package com.rbu.uti;

import org.springframework.stereotype.Component;

@Component
public class Eutil {
	public Eutil() {
		System.out.println("Eutil()");
	}

}
