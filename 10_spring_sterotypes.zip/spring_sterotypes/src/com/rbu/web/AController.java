package com.rbu.web;

import org.springframework.stereotype.Controller;

@Controller
public class AController {
	public AController() {
		System.out.println("AController()");
	}

}
