package com.org.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DConfig {
	public DConfig() {
		System.out.println("DConfig()");
	}

}
