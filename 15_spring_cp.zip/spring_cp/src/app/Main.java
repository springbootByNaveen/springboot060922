package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ds.web.StudentController;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/ioc.xml");
		StudentController controller = context.getBean(StudentController.class);

		for (int i = 10000; i < 20000; i++) {
			int studentId = i + 1;
			String name = "testName" + studentId;
			String email = "testEamil" + studentId;
			String address = "testaddress" + studentId;

			try {
				controller.createStudentAPI(studentId, name, email, address);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}
}
