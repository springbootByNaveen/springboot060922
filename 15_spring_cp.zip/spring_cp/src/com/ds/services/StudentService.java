package com.ds.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.repository.StudentRepo;

@Service
public class StudentService {
	@Autowired
	StudentRepo repo;
	public void createStudent(int id, String name, String email, String address) throws Exception {
		repo.save(id, name, email, address);
	}
	
}
