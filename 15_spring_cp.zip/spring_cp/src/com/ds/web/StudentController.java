package com.ds.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ds.services.StudentService;

@Controller
public class StudentController {
	@Autowired
	StudentService service;
	
	public void createStudentAPI(int id, String name, String email, String address) throws Exception {
		service.createStudent(id, name, email, address);
	}
	
	

}
