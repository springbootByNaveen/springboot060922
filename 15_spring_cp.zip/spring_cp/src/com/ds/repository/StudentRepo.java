package com.ds.repository;

import java.sql.Connection;
import java.sql.Statement;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StudentRepo {
	@Autowired
	BasicDataSource dataSource;

	public void save(int id, String name, String email, String address) throws Exception {
		Connection con = dataSource.getConnection();
		Statement statement = con.createStatement();
		statement.executeUpdate(
				"insert into STUDENT_TABLE values(" + id + ",'" + name + "','" + email + "','" + address + "')");
		System.out.println("success:" + id);
		statement.close();
		con.close();
	}

}
