package app;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import beans.Test1;
import beans.Test2;

public class Main {
	public static void main(String[] args) {
		// lazy one
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("resources/ioc.xml"));
		System.out.println("----------------------------------------------------------");

		
		Test1 t1 = (Test1) factory.getBean("t1");
		//t1.hai();
		Test2 t2 = (Test2) factory.getBean("t2");
		//t2.hello();
		Test1 t3 = (Test1) factory.getBean("t1");
		//t3.hai();
		Test2 t4 = (Test2) factory.getBean("t2");
		//t4.hello();
		System.out.println(t1==t3);// ture  
		System.out.println(t2==t4);// ture
	}
	
}
