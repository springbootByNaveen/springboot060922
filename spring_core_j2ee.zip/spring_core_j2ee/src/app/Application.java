package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Test1;
import beans.Test2;

public class Application {
	public static void main(String[] args) {
		// early
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/ioc.xml");
		System.out.println("----------------------------------------------------------");
		Test1 t1 = (Test1) context.getBean("t1");
		Test2 t2 = (Test2) context.getBean("t2");
		Test1 t3 = (Test1) context.getBean("t1");
		Test2 t4 = (Test2) context.getBean("t2");
		context.getBean("t1");
		context.getBean("t1");
		context.getBean("t1");
		context.getBean("t1");
		context.getBean("t2");
		context.getBean("t2");
		context.getBean("t2");
		context.getBean("t2");

	}
}
