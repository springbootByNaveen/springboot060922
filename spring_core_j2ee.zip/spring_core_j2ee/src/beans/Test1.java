package beans;
public class Test1 {
public Test1() {
System.out.println("Test1");
}

public void hai() {
	System.out.println("Hai..");
}
}
