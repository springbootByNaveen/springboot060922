package beans;
public class Test2 {
public Test2() {
System.out.println("Test2");
}

public void hello() {
	System.out.println("hello..");
}
}
