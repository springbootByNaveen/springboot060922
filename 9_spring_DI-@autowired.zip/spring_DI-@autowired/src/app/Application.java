package app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Car;

public class Application {
	public static void main(String[] args) {
		// early
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/ioc.xml");
		System.out.println("----------------------------------------------------------");
		
		Car car=context.getBean(Car.class);
		car.carInfo();
	}
}
