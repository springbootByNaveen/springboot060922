package beans;

public class Engine implements EngInterface {
	private String engineCC;

	public void setEngineCC(String engineCC) {
		this.engineCC = engineCC;
	}

	public String getEngineCC() {
		return engineCC;
	}
}
