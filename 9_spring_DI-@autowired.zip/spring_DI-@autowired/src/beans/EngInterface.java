package beans;

public interface EngInterface {
	public void setEngineCC(String engineCC);
	public String getEngineCC();
}
