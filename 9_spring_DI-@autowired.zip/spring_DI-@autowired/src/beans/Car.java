package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Car {
	@Qualifier("e2")
	@Autowired
	private EngInterface engine;
	
	
	public void carInfo() {
		System.out.println("car power=" + engine.getEngineCC());
	}
}
