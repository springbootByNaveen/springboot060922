package beans;

public class JetEngine implements EngInterface {
	private String engineCC;

	public void setEngineCC(String engineCC) {
		this.engineCC = engineCC;
	}

	public String getEngineCC() {
		return engineCC;
	}
}
