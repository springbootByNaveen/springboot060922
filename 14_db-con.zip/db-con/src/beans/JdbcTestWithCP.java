package beans;

import java.sql.Connection;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;

public class JdbcTestWithCP {
	public static void main(String[] args) {
//to increse number of db connections admin command: alter system set processes=19 scope=spfile
		
		
		BasicDataSource bds=new BasicDataSource();
		bds.setDriverClassName("oracle.jdbc.OracleDriver");
		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		bds.setUsername("system");
		bds.setPassword("admin");
		bds.setMaxActive(150);
		bds.setMaxWait(2000);
		
		for (int i = 0; i < 1000000; i++) {
			try {
				
	
				Connection con = bds.getConnection();
				System.out.println(i+":"+con);
				con.close();
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			
			
		}

	}
}
