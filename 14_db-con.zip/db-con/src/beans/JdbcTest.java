package beans;

import java.sql.Connection;
import java.sql.DriverManager;

public class JdbcTest {
	public static void main(String[] args) {
//to increse number of db connections admin command: alter system set processes=19 scope=spfile
		for (int i = 0; i < 10000; i++) {
			try {
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
				System.out.println(i+":"+con);
				con.close();
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			
			
		}

	}
}
