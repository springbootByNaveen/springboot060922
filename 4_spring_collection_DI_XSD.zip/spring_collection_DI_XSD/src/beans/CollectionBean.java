package beans;

import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

public class CollectionBean {
	private List<String> fruits;
	private LinkedList<String> alpL;
	private TreeSet<String> alpU;
	private TreeMap<String,String> stateCap;
	
	public void setFruits(List<String> fruits) {
		this.fruits = fruits;
	}
	public void setAlpL(LinkedList<String> alpL) {
		System.out.println("setAlpL");
		this.alpL = alpL;
	}
	public void setAlpU(TreeSet<String> alpU) {
		System.out.println("setAlpU");
		this.alpU = alpU;
	}
	public void setStateCap(TreeMap<String, String> stateCap) {
		System.out.println("setStateCap");
		this.stateCap = stateCap;
	}
	@Override
	public String toString() {
		return "CollectionBean [fruits=" + fruits + ", alpL=" + alpL + ", alpU=" + alpU + ", stateCap=" + stateCap
				+ "]";
	}
	
	
	

}
